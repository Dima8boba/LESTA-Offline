# -- coding: utf-8 --
"""Set up the offline battle only after the virtual account is active."""
import sys
from debug_utils import LOG_CURRENT_EXCEPTION

_installed = False

def install():
    global _installed
    if _installed:
        return
    mod = sys.modules.get('gui.mods.mod_offhangar') or sys.modules.get('mod_offhangar')
    if mod is None:
        raise ImportError('Offline login module missing')
    import gui.mods.offhangar.battle as battle
    import gui.mods.offhangar.physics as physics
    import gui.mods.offhangar.bots as bots
    try:
        physics.install()
    except Exception:
        LOG_CURRENT_EXCEPTION()
    original_enter = battle.enterOfflineBattle
    original_leave = battle.leaveOfflineBattle

    def enterOfflineBattle(vehInvID=0, mapName=None):
        result = original_enter(vehInvID=vehInvID, mapName=mapName)
        try:
            physics.start()
        except Exception:
            LOG_CURRENT_EXCEPTION()
        return result

    def leaveOfflineBattle():
        try:
            physics.clear_bodies()
        except Exception:
            LOG_CURRENT_EXCEPTION()
        try:
            return original_leave()
        finally:
            try:
                physics.clear_bodies()
            except Exception:
                LOG_CURRENT_EXCEPTION()

    mod._offhangar_enterOfflineBattle = original_enter
    mod._offhangar_leaveOfflineBattle = original_leave
    mod.offhangar_physics = physics
    mod.offhangar_bots = bots
    mod.offhangar_battle = battle
    mod.enterOfflineBattle = battle.enterOfflineBattle = enterOfflineBattle
    mod.leaveOfflineBattle = battle.leaveOfflineBattle = leaveOfflineBattle
    _installed = True
